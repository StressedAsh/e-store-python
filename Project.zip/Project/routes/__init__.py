from .api_customers import api_customers_bp
from .api_product_bp import api_products_bp
from .api_orders_bp import api_order_bp    
from .html_bp import htmls_bp